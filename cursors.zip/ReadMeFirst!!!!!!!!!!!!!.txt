First:

Extract all files into your Cursors file under the Windows file.
Do the same for both disks.

Second:

Under mouse in the control panel, select the tab that says Pointers 
or it might say Cursors.  


Third:

Under that colum, select which ever pointer 
you want to change, and select the Browse button.  There you will see
a list of all avable pointers.  You can view what each one does before
you chose the OK button by clicking on one once then looking at the
box twards the bottom left.

Fourth:

Select OK button when you find the one you like.  When you get back 
to the mouse properties, repeat step 3 for each aditional one you 
want to change.  

Fifth:

Select the Save As button and put in what ever name you want!
Then select the Use Defult button.
Then Select the Apply button.
Last click OK and your done!